package com.gaptech.loyalty.customervalue.functionaltests.common;

import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Slf4j
public class Utility {

    public static final String CUSTOMER_VALUE_SERVICE_BASE_URL = "https://secure-internal-azeus-ecom-api.live.stage.gaptechol.com/commerce";

    public static final String CUSTOMER_VALUE_REQUEST = "customerValueRequest";
    public static final String CUSTOMER_VALUE_RESPONSE = "customerValueResponse";
    public static final String VAULT_ID = "vaultId";
    public static final String EMAIL = "Email";
    public static final String PHONE_NUMBER = "phoneNumber";

    public static final String DT_PROMOTION_CODE = "promotionCode";
    public static final String DT_BAR_CODE = "barCode";
    public static final String DT_RETAIL_VALUE = "retailValue";
    public static final String DT_PROMOTION_ID = "promotionId";
    public static final String DT_STATUS = "status";
    public static final String DT_END_DATE_TIME = "endDateTime";
    public static final String DT_AMOUNT = "amount";
    public static final String DT_VAULT_ID = "vaultId";

    public static final String DATE_FORMATTER = "yyyy-MM-dd";

    public static final String REFERER_URL = "https://secure-azeus-www.live.stage.gaptechol.com/loyalty/customer-value";

    public static final String SUMMARY_ENDPOINT = "/summary";
    public static final String CUSTOMER_VALUE_SUMMARY_REQUEST = "customerValueSummaryRequest";
    public static final String CUSTOMER_VALUE_SUMMARY_RESPONSE = "customerValueSummaryResponse";
    public static final String CUSTOMER_VALUE_SUMMARY_RESPONSE_BODY = "customerValueSummaryResponseBody";

    public static final String API_KEY = "eSwsHnVed94dK4Qfpl0RGTArIqC79ADm";


    public static final String TOKEN_URL = "https://stage.api.azeus.gaptech.com/commerce/credentials-daemon/token?grant_type=client_credentials";
    public static final String CUSTOMER_VALUE_APIGEE_BASE_URL = "https://stage.api.azeus.gaptech.com/commerce/customer-value/";
    public static final String GRANT_TYPE = "grant_type";
    public static final String AUTHORIZATION = "Basic dmxYSmE0Wmc2OUdaek1CR0hYdko5dmRDMldrb2Z6aXg6SVhtWlJZU0twdnJ1bU1JWA==";
    public static final String TOKEN_RESPONSE = "tokenresponse";
    public static final String Customer_Value_Get_RESPONSE = "customervaluegetresponse";
    public static final String API_VERSION_HEADER = "apiVersion";
    public static final String CLIENT_ID_HEADER = "client-id";
    public static final String AUTH_HEADER = "Authorization";
    public static final String EXTERNAL_CUSTOMER_ID = "externalCustomerId";
    public static final String ACCESS_TOKEN = "accessToken";
    public static final CharSequence TOKEN_TYPE_BEARER = "Bearer";
    public static final String CVS_APIGEE_BASE_URL = "https://stage.api.azeus.gaptech.com/commerce/customer-value";
    public static final String CUSTOMER_VALUE_GET_DETAILS_URL = "customervaluegetdetailsurl";
    public static final String RESPONSE = "response";

    public static boolean isExpire(String date) {
        if (date.isEmpty() || date.trim().equals("")) {
            return false;
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            Date d = null;
            Date d1 = null;
            String today = getToday("yyyy-MM-dd'T'HH:mm:ss");
            try {
                d = sdf.parse(date);
                d1 = sdf.parse(today);
                if (d1.compareTo(d) < 0) {// not expired
                    return false;
                } else if (d.compareTo(d1) == 0) {// both date are same
                    if (d.getTime() < d1.getTime()) {// not expired
                        return false;
                    } else if (d.getTime() == d1.getTime()) {//expired
                        return true;
                    } else {//expired
                        return true;
                    }
                } else {//expired
                    return true;
                }
            } catch (ParseException e) {
                log.debug("Exception while parsing date [] ", e);
                return false;
            }
        }
    }


    private static String getToday(String format) {
        Date date = new Date();
        return new SimpleDateFormat(format).format(date);
    }
}
