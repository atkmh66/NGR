package com.gaptech.loyalty.customervalue.functionaltests.model;

import java.util.HashMap;
import java.util.Map;

public enum Brands {
    GP("1"),
    BR("2"),
    ON("3"),
    GPFS("5"),
    BRFS("6"),
    AT("10");

    private String brandCode;

    Brands(String brandCode) {
        this.brandCode = brandCode;
    }

    public String getBrandCode() {
        return brandCode;
    }

    private static final Map<String, Brands> lookup = new HashMap<>();

    static {
        for(Brands brand : Brands.values()) {
            lookup.put(brand.getBrandCode(), brand);
        }
    }

    public static Brands get(String brandCode) {
        return lookup.get(brandCode);
    }
}
