package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Offer {

    public static final String GAP_ID = "1";
    public static final String GAP_FACTORY_ID = "5";

    private String brandCode;

    private String brandName;

    private OfferDiscount discount;

    private BurnPeriod burnPeriod;

    private List<PromotionMessage> promotionMessages;

    private List<String> applicableChannels;

    private String errorMessage;

    public String getBrandCode() {
        if (GAP_FACTORY_ID.equals(brandCode)) {
            return GAP_ID;
        }
        return brandCode;
    }
}
