package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Value;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Value
@Builder
@JsonInclude(NON_NULL)
public class ErrorModel {

    private Integer statusCode;

    private String errorCode;

    private String developerMessage;

    private String userMessage;

    private String moreInfo ;
}
