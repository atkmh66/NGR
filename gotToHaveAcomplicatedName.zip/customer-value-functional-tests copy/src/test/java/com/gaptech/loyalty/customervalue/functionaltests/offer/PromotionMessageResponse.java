package com.gaptech.loyalty.customervalue.functionaltests.offer;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class PromotionMessageResponse {

    private String localeCode;
    private String legalTerms;
    private String marketingDescription;
}
