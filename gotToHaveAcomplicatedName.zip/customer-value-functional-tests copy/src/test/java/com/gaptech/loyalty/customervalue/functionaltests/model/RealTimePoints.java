package com.gaptech.loyalty.customervalue.functionaltests.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Builder
@Value
@AllArgsConstructor
public class RealTimePoints {
    String alchemyId;
    CreditCardPoints points;
}
