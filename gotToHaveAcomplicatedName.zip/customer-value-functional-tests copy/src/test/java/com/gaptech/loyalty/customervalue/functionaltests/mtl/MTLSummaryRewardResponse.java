package com.gaptech.loyalty.customervalue.functionaltests.mtl;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class MTLSummaryRewardResponse {

    @JsonIgnore
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String barCode;
    @JsonIgnore
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String certificateNumber;
    private String certificateStatusDesc;
    private String expirationDate;
    private String profileId;
    private String promoDescription;
    private String promoId;
    private int retailValue;
    private String rewardCode;
    private String rewardType;
    private String status;
    private String title;
}
