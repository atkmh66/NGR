package com.gaptech.loyalty.customervalue.functionaltests.creditcard;

import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class CreditCardRewardResponse {

    private String identifier;
    private List<RewardResponse> reward;
}
