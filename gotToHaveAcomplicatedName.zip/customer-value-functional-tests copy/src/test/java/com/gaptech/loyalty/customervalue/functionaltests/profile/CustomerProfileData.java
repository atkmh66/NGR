package com.gaptech.loyalty.customervalue.functionaltests.profile;

import lombok.Builder;
import lombok.Value;

import java.time.ZonedDateTime;

@Value
@Builder
public class CustomerProfileData {
    private String externalCustomerId;
    private String emailAddress;
    private String firstName;
    private String lastName;
    private String gender;
    private String registrationBrand;
    private String accountType;
    private String isActive;
    private String marketCode;
    private String createdBy;
    private String updatedBy;
    private ZonedDateTime creationDate;
    private ZonedDateTime updatedDate;
}
