package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditCardReward {

    private String barCode;

    private String expirationDateTime;

    private String legalTerms;

    private String promoDescription;

    private String promotionCode;

    private String promotionId;

    private Integer retailValue;

    private String startDateTime;

    @JsonIgnore
    private String vaultId;

    private String errorMessage;
}
