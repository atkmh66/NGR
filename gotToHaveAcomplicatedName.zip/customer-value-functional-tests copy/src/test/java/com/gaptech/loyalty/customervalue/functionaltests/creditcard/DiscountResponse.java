package com.gaptech.loyalty.customervalue.functionaltests.creditcard;

import lombok.Builder;
import lombok.Value;

import java.math.BigDecimal;

@Value
@Builder
public class DiscountResponse {

    private String code;
    private String barCode;
    private BigDecimal amount;
    private String type;
    private String startDateTime;
    private String endDateTime;
    private String legalTerms;
    private String promotionId;
}
