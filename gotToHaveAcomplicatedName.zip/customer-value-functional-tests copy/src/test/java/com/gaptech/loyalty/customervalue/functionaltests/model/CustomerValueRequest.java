package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Pattern;
import java.util.List;
import java.util.Set;

@Value
@Builder
@AllArgsConstructor
public class CustomerValueRequest {

    @JsonProperty(value = "email")
    private String email;

    @JsonProperty(value = "phoneNumber")
    private String phoneNumber;

    @JsonProperty(value = "vaultIds")
    private List<String> vaultIds;

    @JsonProperty(value = "market")
    private String marketCode;

    @JsonProperty(value = "filters")
    private Set<String> filters;

    @JsonProperty(value = "brand")
    private String brand;

    @JsonProperty(value = "externalCustomerId")
    private String externalCustomerId;

}
