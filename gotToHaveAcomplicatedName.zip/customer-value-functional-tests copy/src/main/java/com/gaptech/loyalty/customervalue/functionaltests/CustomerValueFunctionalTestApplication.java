package com.gaptech.loyalty.customervalue.functionaltests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerValueFunctionalTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomerValueFunctionalTestApplication.class, args);
    }

}
