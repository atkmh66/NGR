## **Customer-Value-Service-Functional-Test-Cases**

This project contains the functional test cases for customer value service.

Git: https://github.gapinc.com/customer/customer-value-service


### **Dev set up**

**IntelliJ**

To import the project, use the Import project option and choose the build.gradle file. Optionally you can enable the Use auto-import option.

After IntelliJ finishes the import and indexing, you have to:

- Install Lombok plugin
- Install scala plugin
- Enable annotation processing in Build, Execution, Deployment, Compiler > Annotation Processors
