package com.gaptech.loyalty.customervalue.functionaltests.mtl;

import lombok.Builder;
import lombok.Value;

import java.util.Set;

@Value
@Builder
public class MTLSummarySearchCriteriaRequest {

    private String type;
    private String value;
    private Set<String> filters;
}
