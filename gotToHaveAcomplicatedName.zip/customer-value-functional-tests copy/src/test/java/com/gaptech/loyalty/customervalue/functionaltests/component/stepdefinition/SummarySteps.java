package com.gaptech.loyalty.customervalue.functionaltests.component.stepdefinition;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.gaptech.loyalty.customervalue.functionaltests.common.Utility;
import com.gaptech.loyalty.customervalue.functionaltests.common.stepdef.BaseStepDef;
import com.gaptech.loyalty.customervalue.functionaltests.model.CustomerValueRequest;
import com.gaptech.loyalty.customervalue.functionaltests.model.CustomerValueSummaryResponse;
import com.jayway.restassured.response.Response;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import static com.jayway.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@Slf4j
public class SummarySteps {

    private static final String CUSTOMER_VALUE_URL = "/customer-value";

    private static final String OFFERS_LABEL = "offers";
    private static final String CARD_REWARDS_LABEL = "cards rewards";
    private static final String NO_VALUE = "NO";
    private static final String EMPTY_VALUE = "NONE";

    private static final long THREAD_SLEEP_TIME = 1000l;
    private static final int BAD_REQUEST = 400;
    private ObjectMapper objectMapper = new ObjectMapper();

    public List<String> listOfString(String values) {
        if (EMPTY_VALUE.equals(values))
            return Collections.<String>emptyList();
        return Arrays.stream(values.split(", ?"))
                .collect(Collectors.toList());
    }

    @Given("^Want to retrieve customer summary with (.*) as filters, (.*) phone, (.*) email and (.*) "+
            "vault ids for the (.*) market$")
    public void retrieveSummary(
            String filters,
            String phone,
            String email,
            String VaultIDs,
            String market) throws JsonProcessingException {

        CustomerValueRequest summaryRequest = CustomerValueRequest.builder()
                .phoneNumber(NO_VALUE.equals(phone)? null: phone)
                .email(NO_VALUE.equals(email)? null: email)
                .vaultIds(NO_VALUE.equals(VaultIDs)? null: listOfString(VaultIDs))
                .marketCode(NO_VALUE.equals(market)? null: market)
                .filters(NO_VALUE.equals(filters)? null: new HashSet<String>(listOfString(filters)))
                .build();

        String requestJson = objectMapper.writeValueAsString(summaryRequest);
        BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_SUMMARY_REQUEST, summaryRequest);
        log.debug("summary request {}", requestJson);
        assertTrue(summaryRequest != null);
    }

    @When("^Make a post to customer value /summary$")
    public void postToCustomerValueSummary() throws IOException {
        CustomerValueRequest summaryRequest = (CustomerValueRequest) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_REQUEST);
        Response response = getSummaryResponse(summaryRequest);

        if (response.getStatusCode() == 200) {
            CustomerValueSummaryResponse summaryResponse =
                    objectMapper.readValue(response.body().asString(), CustomerValueSummaryResponse.class);
            BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE_BODY, summaryResponse);
        }

        BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE, response);
    }

    @And("^Summary response is Bad Request")
    public void bad_request() {
        Response response = (Response) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);
        assertEquals(response.statusCode(), BAD_REQUEST);
    }

    @And("^Developer message includes: (.*)$")
    public void developerMessageIncludesThisMessage(String theMessage) {
        Response response = (Response) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);
        assertTrue(response.body().asString().contains(theMessage));
    }

    @Then("^(offers|cards rewards) should be empty$")
    public void fieldShouldBeEmpty(String field) {
        CustomerValueSummaryResponse summaryResponse =
                (CustomerValueSummaryResponse) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE_BODY);
        if (OFFERS_LABEL.equals(field))
            assertTrue(summaryResponse.getOffers() == null || summaryResponse.getOffers().isEmpty());
        if (CARD_REWARDS_LABEL.equals(field))
            assertTrue(summaryResponse.getCards() == null || summaryResponse.getCards().isEmpty());
    }



    @Then("^mtl rewards should be empty$")
    public void mtlIsNull() {
        CustomerValueSummaryResponse summaryResponse =
                (CustomerValueSummaryResponse) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE_BODY);
        assertTrue(summaryResponse.getMtl() == null);
    }

    @Then("^mtl rewards total is: (.*)$")
    public void mtlTotalIs(int total) {
        CustomerValueSummaryResponse summaryResponse =
                (CustomerValueSummaryResponse) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE_BODY);
        assertEquals(summaryResponse.getMtl().getTotalRewards().intValue(), total);
    }

    @And("^(offers|cards rewards) length is (\\d+)$")
    public void offersLengthIs(String field, int numberOfElements) {
        CustomerValueSummaryResponse summaryResponse =
                (CustomerValueSummaryResponse) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE_BODY);
        if (OFFERS_LABEL.equals(field))
            assertEquals(numberOfElements, summaryResponse.getOffers().size());
        if (CARD_REWARDS_LABEL.equals(field))
            assertEquals(numberOfElements, summaryResponse.getCards().size());
    }

    @And("^Have (\\d+) card reward of (\\d+)$")
    public void haveACardRewardOf(int count, int amount) {
        CustomerValueSummaryResponse summaryResponse =
                (CustomerValueSummaryResponse) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE_BODY);

        long rewardsFound =summaryResponse.getCards().stream().filter(
                cardSummary -> cardSummary.getTotalRewards().intValue() == amount
        ).count();
        assertTrue("Found "+rewardsFound+" instead of "+count,rewardsFound == count);
    }

    @And("^Have (\\d+) offer of (\\d+)$")
    public void haveOfferOf(int count, int amount) {
        CustomerValueSummaryResponse summaryResponse =
                (CustomerValueSummaryResponse) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE_BODY);

        long offersFound = summaryResponse.getOffers().stream().filter(
                offerSummary -> offerSummary.getAmount().intValue() == amount
        ).count();
        assertTrue("Found "+offersFound+" instead of "+count,offersFound == count);
    }

    private Response getSummaryResponse(CustomerValueRequest summaryRequest) throws JsonProcessingException {
        String requestJson = objectMapper.writeValueAsString(summaryRequest);
        Response response = given()
                .contentType(APPLICATION_JSON_UTF8_VALUE)
                .content(requestJson)
                .headers("referer", Utility.REFERER_URL)
                .headers("apikey", Utility.API_KEY)
                .post(Utility.CUSTOMER_VALUE_SERVICE_BASE_URL + CUSTOMER_VALUE_URL+ Utility.SUMMARY_ENDPOINT);
        try {
            Thread.sleep(THREAD_SLEEP_TIME);
        } catch (InterruptedException e) {
            log.error("Exception occurred while sleeping thread after summary request {}", e.getMessage());
        }
        String responseJson = response.body().asString();
        log.debug("summary response {} {}", response.getStatusCode(), responseJson);

        return response;
    }
}
