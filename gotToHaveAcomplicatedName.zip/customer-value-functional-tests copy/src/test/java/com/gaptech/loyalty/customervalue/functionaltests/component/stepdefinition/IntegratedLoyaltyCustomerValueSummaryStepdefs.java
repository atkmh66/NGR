package com.gaptech.loyalty.customervalue.functionaltests.component.stepdefinition;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gaptech.loyalty.customervalue.functionaltests.common.Utility;
import com.gaptech.loyalty.customervalue.functionaltests.common.stepdef.BaseStepDef;
import com.gaptech.loyalty.customervalue.functionaltests.model.CardSummary;
import com.gaptech.loyalty.customervalue.functionaltests.model.CustomerValueRequest;
import com.gaptech.loyalty.customervalue.functionaltests.model.CustomerValueSummaryResponse;
import com.jayway.restassured.filter.log.RequestLoggingFilter;
import com.jayway.restassured.filter.log.ResponseLoggingFilter;
import com.jayway.restassured.response.Response;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static com.jayway.restassured.RestAssured.given;
import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.*;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@Slf4j
public class IntegratedLoyaltyCustomerValueSummaryStepdefs {

    private ObjectMapper objectMapper = new ObjectMapper();

    @Given("^Integrated loyalty CVS Summary request with headers client-id (.*) and apiVersion (.*)$")
    public void integratedLoyaltyFlagAndHeaderApiVersion(String clientId, String apiVersion) {
        BaseStepDef.setAttribute(Utility.CLIENT_ID_HEADER, clientId);
        BaseStepDef.setAttribute(Utility.API_VERSION_HEADER, apiVersion);
    }

    @Given("^A loyalty customer with profileId (.*) VaultIds (.*) and email (.*)$")
    public void integratedLoyaltyCustomerWithVaultIdsAndEmail(String profileId,List<String> vaultIds, String email) {
        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.EMAIL, email);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, null);
        BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, profileId);
    }

    @When("^Make post call to integrated loyalty customer value summary api with market (.*), brand (.*)" +
            " and below filters$")
    public void postCallToIntegratedLoyaltyCustomerValueSummaryApi(String market, String brand,
                                                                   List<String> filters) throws IOException {
        log.debug("Calling customer value Summary service [{}]", Utility.CVS_APIGEE_BASE_URL+Utility.SUMMARY_ENDPOINT);

        if (filters.contains("NULL")) {
            filters = new ArrayList<>();
        }

        Set<String> filterSet = filters.stream().collect(Collectors.toSet());
        CustomerValueRequest customerValueRequest = CustomerValueRequest.builder()
                .vaultIds((List<String>) BaseStepDef.getAttribute(Utility.VAULT_ID))
                .email((String) BaseStepDef.getAttribute(Utility.EMAIL))
                .phoneNumber((String) BaseStepDef.getAttribute(Utility.PHONE_NUMBER))
                .brand(brand.equals("null")?null:brand)
                .filters(filterSet)
                .marketCode(market.equals("null")?null:market)
                .externalCustomerId((String) BaseStepDef.getAttribute(Utility.EXTERNAL_CUSTOMER_ID))
                .build();

        BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_REQUEST, customerValueRequest);

        Map<String, String> headers = new HashMap<>();
        headers.put(Utility.CLIENT_ID_HEADER, (String) BaseStepDef.getAttribute(Utility.CLIENT_ID_HEADER));
        String accessToken = (String) BaseStepDef.getAttribute(Utility.ACCESS_TOKEN);
        headers.put(Utility.AUTH_HEADER, Utility.TOKEN_TYPE_BEARER + accessToken);
        headers.put(Utility.API_VERSION_HEADER, (String) BaseStepDef.getAttribute(Utility.API_VERSION_HEADER));

        Response response = given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter())
                .contentType(APPLICATION_JSON_UTF8_VALUE)
                .content(objectMapper.writeValueAsString(customerValueRequest))
                .headers(headers)
                .when()
                .post(Utility.CVS_APIGEE_BASE_URL+Utility.SUMMARY_ENDPOINT);

        assertNotNull(response);

        BaseStepDef.setAttribute(Utility.RESPONSE, response);
        if (response.getStatusCode() == 200 && Objects.nonNull(response.body())) {
            CustomerValueSummaryResponse customerValueSummaryResponse =
                    objectMapper.readValue(response.body().asString(), CustomerValueSummaryResponse.class);
            BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE, customerValueSummaryResponse);
            log.debug("Customer Value Summary Response [{}]", response.body().asString());
        } else {
            log.debug("Customer Value Summary Response [{}]", response.getStatusLine());
        }
    }

    @And("^Should return mtl points response data fields such as activePoints, pendingPoints," +
            " totalPoints, activePointsAmount, pendingPointsAmount and totalPointsAmount$")
    public void shouldReturnMtlPointsResponseAndValidateForSummary() {
        CustomerValueSummaryResponse customerValueResponse = (CustomerValueSummaryResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);
        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getMtl());
        assertNotNull(customerValueResponse.getMtl().getMtlPoints());
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getActivePoints() >= 0);
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getPendingPoints() >= 0);
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getTotalPoints() >= 0);
        int expectedTotalPoints = customerValueResponse.getMtl().getMtlPoints().getTotalPoints();
        int calculatedTotalPoints = customerValueResponse.getMtl().getMtlPoints().getActivePoints()
                + customerValueResponse.getMtl().getMtlPoints().getPendingPoints();
        assertEquals(expectedTotalPoints, calculatedTotalPoints);
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getActivePointsAmount()
                .compareTo(BigDecimal.ZERO) >= 0);
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getPendingPointsAmount()
                .compareTo(BigDecimal.ZERO) >= 0);
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getTotalPointsAmount()
                .compareTo(BigDecimal.ZERO) >= 0);
        BigDecimal expectedTotalPointsAmount = customerValueResponse.getMtl().getMtlPoints().getTotalPointsAmount();
        BigDecimal calculatedTotalPointsAmount = customerValueResponse.getMtl().getMtlPoints().getActivePointsAmount()
                .add(customerValueResponse.getMtl().getMtlPoints().getPendingPointsAmount());
        assertEquals(expectedTotalPointsAmount, calculatedTotalPointsAmount);
        log.debug("Assertion successful for MTL Points for various fields data!!!");
    }

    @And("^Should return mtl rewards as totalRewards$")
    public void shouldReturnMtlRewardsResponseForSummary() {
        CustomerValueSummaryResponse customerValueResponse = (CustomerValueSummaryResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);

        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getMtl());
        assertNotNull(customerValueResponse.getMtl().getTotalRewards());
        assertTrue(customerValueResponse.getMtl().getTotalRewards().compareTo(BigDecimal.ZERO) >= 0);
        log.debug("Assertion successful for MTL Rewards!!!");

    }

    @And("^GrandTotalAmount should match sum of all mtlPoints,mtlRewards and cards$")
    public void shouldReturnGrandTotalAmountForSummary() {
        CustomerValueSummaryResponse customerValueResponse = (CustomerValueSummaryResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);

        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getGrandTotalAmount());
        BigDecimal expectedGrandTotal = customerValueResponse.getGrandTotalAmount();
        BigDecimal mtlPoints = customerValueResponse.getMtl().getMtlPoints()==null?BigDecimal.ZERO:customerValueResponse.getMtl().getMtlPoints().getActivePointsAmount();
        BigDecimal mtlRewards = customerValueResponse.getMtl().getTotalRewards()==null?BigDecimal.ZERO:customerValueResponse.getMtl().getTotalRewards();
        BigDecimal cardRewards = (customerValueResponse.getCards()==null||customerValueResponse.getCards().isEmpty())?BigDecimal.ZERO:
                customerValueResponse.getCards().stream().map(card->card.getTotalRewards()).reduce(BigDecimal.ZERO,BigDecimal::add);
        BigDecimal calculatedGrandTotal =  mtlPoints.add(mtlRewards).add(cardRewards);
        assertEquals(expectedGrandTotal,calculatedGrandTotal);
        log.debug("Assertion successful for Grand Total Amount!!!");

    }

    @And("^Should return mtl points response data fields amounts as Zero$")
    public void shouldReturnMtlPointsResponseWithAllZeroValues() {
        CustomerValueSummaryResponse customerValueResponse = (CustomerValueSummaryResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);
        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getMtl());
        assertNotNull(customerValueResponse.getMtl().getMtlPoints());
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getActivePoints() == 0);
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getPendingPoints() == 0);
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getTotalPoints() == 0);
        int expectedTotalPoints = customerValueResponse.getMtl().getMtlPoints().getTotalPoints();
        int calculatedTotalPoints = customerValueResponse.getMtl().getMtlPoints().getActivePoints()
                + customerValueResponse.getMtl().getMtlPoints().getPendingPoints();
        assertEquals(expectedTotalPoints, calculatedTotalPoints);
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getActivePointsAmount()
                .compareTo(BigDecimal.ZERO) == 0);
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getPendingPointsAmount()
                .compareTo(BigDecimal.ZERO) == 0);
        assertTrue(customerValueResponse.getMtl().getMtlPoints().getTotalPointsAmount()
                .compareTo(BigDecimal.ZERO) == 0);
        BigDecimal expectedTotalPointsAmount = customerValueResponse.getMtl().getMtlPoints().getTotalPointsAmount();
        BigDecimal calculatedTotalPointsAmount = customerValueResponse.getMtl().getMtlPoints().getActivePointsAmount()
                .add(customerValueResponse.getMtl().getMtlPoints().getPendingPointsAmount());
        assertEquals(expectedTotalPointsAmount, calculatedTotalPointsAmount);
        log.debug("Assertion successful for MTL Points for various fields data!!!");
    }

    @And("^Should not return mtl rewards$")
    public void shouldNotReturnMtlRewardsResponseForSummary() {
        CustomerValueSummaryResponse customerValueResponse = (CustomerValueSummaryResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);

        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getMtl());
        assertNull(customerValueResponse.getMtl().getTotalRewards());
        log.debug("Assertion successful for MTL Rewards!!!");

    }

    @And("^offers Object Should be Empty$")
    public void shouldNotReturnOffersForSummary() {
        CustomerValueSummaryResponse customerValueResponse = (CustomerValueSummaryResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);

        assertNotNull(customerValueResponse);
        assertNull(customerValueResponse.getOffers());
        log.debug("Assertion successful for Offers!!!");

    }

    @And("^Credit Cards Object Should be Empty$")
    public void shouldNotReturnCreditCardsForSummary() {
        CustomerValueSummaryResponse customerValueResponse = (CustomerValueSummaryResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);

        assertNotNull(customerValueResponse);
        assertNull(customerValueResponse.getCards());
        log.debug("Assertion successful for Offers!!!");

    }

    @And("^Offers Object Should not be Empty or Null$")
    public void shouldNotReturnEmptyOrNullInOffersForSummary() {
        CustomerValueSummaryResponse customerValueResponse = (CustomerValueSummaryResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);

        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getOffers());
        assertFalse(customerValueResponse.getOffers().isEmpty());
        log.debug("Assertion successful for Offers!!!");

    }
    @And("^Credit cards rewards size should be (\\d+)$")
    public void offersLengthIs(int numberOfElements) {
        CustomerValueSummaryResponse customerValueResponse = (CustomerValueSummaryResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_SUMMARY_RESPONSE);
        assertNotNull(customerValueResponse.getCards());
        assertFalse(customerValueResponse.getCards().isEmpty());
        Assert.assertEquals(numberOfElements, customerValueResponse.getCards().size());
    }

    @Then("^Should receive (.*) with Error message as (.*)")
    public void bad_request(int statusCode, String theMessage) {
        Response response = (Response) BaseStepDef.getAttribute(Utility.RESPONSE);
        assertNotNull(response);
        Assert.assertEquals(response.statusCode(), statusCode);
        assertTrue(response.body().asString().contains(theMessage));
    }

    @Given("^A loyalty customer with the externalCustomerId as (.*) VaultIds as (.*) and email as (.*) for Negative Scenarios$")
    public void integratedLoyaltyCustomerWithVaultIdsAndEmailNegativeScenarios(String profileId,List<String> vaultIds, String email) {
            BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
            BaseStepDef.setAttribute(Utility.EMAIL, email.equals("null")?null:email);
            BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, profileId);
    }
}
