package com.gaptech.loyalty.customervalue.functionaltests.profile;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class CreditCardEntity {
    @JsonProperty("Id")
    private String id;

    @JsonProperty("Type")
    private String type;

    @JsonProperty("CreditCardType")
    private String creditCardType;

    @JsonProperty("Number")
    private String number;

    @JsonProperty("NumberId")
    private String numberId;

    @JsonProperty("ExpirationMonth")
    private String expirationMonth;

    @JsonProperty("ExpirationYear")
    private String expirationYear;

    @JsonProperty("Brand")
    private String brand;

    @JsonProperty("Tier")
    private String tier;

    @JsonProperty("NearTierCode")
    private String nearTierCode;

    @JsonProperty("TemporaryCardIndicator")
    private String temporaryCardIndicator;

    @JsonProperty("Hash")
    private String hash;

    @JsonProperty("Token")
    private String token;

    @JsonProperty("VaultID")
    private String vaultID;

    @JsonProperty("AlchemyID")
    private String alchemyID;

    @JsonProperty("ExpirationMonthVaultID")
    private String expirationMonthVaultID;

    @JsonProperty("ExpirationYearVaultID")
    private String expirationYearVaultID;

    @JsonProperty("LastFourDigits")
    private String lastFourDigits;

    @JsonProperty("IssueDate")
    private String issueDate;

    @JsonProperty("PaymentStatus")
    private String paymentStatus;

    @JsonProperty("CvvValidated")
    private String cvvValidated;

    @JsonProperty("BillingAddressId")
    private String billingAddressId;

    @JsonProperty("SaveCcInProfile")
    private String saveCcInProfile;

    @JsonProperty("UpdateFromPlaceOrder")
    private String updateFromPlaceOrder;

    @JsonProperty("UpdatedDate")
    private String updatedDate;

    @JsonProperty("CardHolderName")
    private String cardHolderName;
}
