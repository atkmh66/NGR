package com.gaptech.loyalty.customervalue.functionaltests.model;

import lombok.Builder;
import lombok.Value;

import java.math.BigDecimal;

@Value
@Builder
public class MtlPoints {

    private int activePoints;
    private int pendingPoints;
    private int totalPoints;
    private int rewardsToBeConvertedFromPoints;
    private int pointsUntilNextReward;
    private int discountReasonCode;
    private int minPoints;
    private int maxPoints;
    private int conversionRate;
    private String programIdentifier;
    private String programEventType;
    private String programName;
    private BigDecimal activePointsAmount;
    private BigDecimal pendingPointsAmount;
    private BigDecimal totalPointsAmount;
    private Integer pointsIncrementalValue;
}
