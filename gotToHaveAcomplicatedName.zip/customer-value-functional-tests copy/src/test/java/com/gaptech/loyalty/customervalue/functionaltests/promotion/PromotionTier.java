package com.gaptech.loyalty.customervalue.functionaltests.promotion;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Feature;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class PromotionTier {

    @JsonFormat(with = Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    private List<Award> awards;
}
