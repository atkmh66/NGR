package com.gaptech.loyalty.customervalue.functionaltests.profile;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProfileLookUpResponse {
    private String externalCustomerId;
    private String customerAccountId;
    private String userMessage;
    private String errorCode;
}
