package com.gaptech.loyalty.customervalue.functionaltests.model;

import java.util.HashMap;
import java.util.Map;

public enum PlccBrands {
    GP("GAPPLCC"),
    BR("BRPLCC"),
    ON("ONPLCC"),
    AT("ATPLCC");

    private String brandCode;

    PlccBrands(String brandCode) {
        this.brandCode = brandCode;
    }

    public String getBrandCode() {
        return brandCode;
    }

    private static final Map<String, PlccBrands> lookup = new HashMap<>();

    static {
        for(PlccBrands brand : PlccBrands.values()) {
            lookup.put(brand.getBrandCode(), brand);
        }
    }

    public static PlccBrands get(String brandCode) {
        return lookup.get(brandCode);
    }
}
