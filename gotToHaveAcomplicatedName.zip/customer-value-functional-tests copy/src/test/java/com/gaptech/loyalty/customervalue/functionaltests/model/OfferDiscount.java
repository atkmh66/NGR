package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Value;

import java.math.BigDecimal;

@Value
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OfferDiscount {

    private BigDecimal amount;
    private String barCode;
    private String promotionCode;
    private String promotionId;
    private String type;
    private String legalTerms;
    private BigDecimal points;
}
