package com.gaptech.loyalty.customervalue.functionaltests.creditcard;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class CreditCardPointsResponse { //NOSONAR

    private int pointsRolledOverSinceLastStatement;
    private int basePointsEarnedInGapBrands;
    private int bonusPointsEarnedInGapBrands;
    private int basePointsEarnedOutsideGapBrands;
    private int bonusPointsEarnedOutsideGapBrands;
    private int quarterlyBonusPoints;
    private int adjustments;
    private int customerCapture;
    private int pointsFromReturnedItems;
    private int pointsToBeConvertedToRewards;
    private int rewardsToBeConvertedFromPoints;
    private int remainingPointsBalance;
    private int pointsUntilNextReward;
    private int totalPointsEarnedTowardsTierStatus;
    private int totalProgressTowardsTierStatus;
    private int pointsRemainingUntilTierStatus;
    private int currentPointsBalance;
    private boolean maxRewardAchieved;
}
