package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Value;

import java.math.BigDecimal;

@Value
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MtlDiscount {

    private String promotionCode;
    private String barCode;
    private BigDecimal retailValue;
    private String type;
    private String endDateTime;
    private String promotionId;
    private String status;
    private String legalTerms;
}
