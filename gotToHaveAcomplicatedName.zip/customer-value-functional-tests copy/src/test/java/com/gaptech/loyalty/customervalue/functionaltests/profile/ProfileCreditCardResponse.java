package com.gaptech.loyalty.customervalue.functionaltests.profile;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProfileCreditCardResponse {
    private String id;
    private String idType;
    private String vaultId;
    private String dateOfBirth;
    private String firstName;
    private String lastName;
    private String accountStatus;
    private String alchemyId;
    private String type;
    private String plccBrand;
    private String issueDate;
    private String creditCardTier;
    private String expirationMonth;
    private String expirationYear;
    private String nearTierCode;
    private Boolean isTemporary;
    private Boolean isCvvValidated;
    private String lastFourDigits;
    private Boolean isDefault;
    private String createdBy;
    private String updatedBy;
    private String creationDate;
    private String updateDate;
    private BillingAddress billingAddress;
}
