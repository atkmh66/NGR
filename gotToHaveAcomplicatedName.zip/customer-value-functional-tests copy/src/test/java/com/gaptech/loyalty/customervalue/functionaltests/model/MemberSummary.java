package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.gaptech.loyalty.customervalue.functionaltests.exception.ErrorModel;
import lombok.Builder;
import lombok.Value;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Value
@Builder
@JsonInclude(NON_NULL)
public class MemberSummary {

    private static final int PHONE_NUMBER_LENGTH = 4;

    private String loyaltyMemberId;

    private String phoneNumber;

    private String lastName;

    private String firstName;

    private String dateOfBirth;

    private List<MtlDiscount> rewards;

    private MtlPoints points;

    private TierStatus tierStatus;

    private String errorMessage;
    private ErrorModel error;
}
