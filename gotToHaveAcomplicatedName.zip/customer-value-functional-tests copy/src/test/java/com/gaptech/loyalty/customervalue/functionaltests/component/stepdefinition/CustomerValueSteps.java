package com.gaptech.loyalty.customervalue.functionaltests.component.stepdefinition;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gaptech.loyalty.customervalue.functionaltests.common.Utility;
import com.gaptech.loyalty.customervalue.functionaltests.common.stepdef.BaseStepDef;
import com.gaptech.loyalty.customervalue.functionaltests.exception.ErrorModel;
import com.gaptech.loyalty.customervalue.functionaltests.model.CreditCardReward;
import com.gaptech.loyalty.customervalue.functionaltests.model.CustomerValueRequest;
import com.gaptech.loyalty.customervalue.functionaltests.model.CustomerValueResponse;
import com.gaptech.loyalty.customervalue.functionaltests.model.MtlDiscount;
import com.gaptech.loyalty.customervalue.functionaltests.model.Offer;
import com.gaptech.loyalty.customervalue.functionaltests.model.OfferDiscount;
import com.jayway.restassured.response.Response;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.RestAssured.requestSpecification;
import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.*;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@Slf4j
public class CustomerValueSteps {

    private static final String CUSTOMER_VALUE_URL = "/customer-value";

    private ObjectMapper objectMapper = new ObjectMapper();

    @Given("^I have a customer with vaultId (.*) and email (.*)$")
    public void customerWithVaultidAndEmail(String vaultId, String email) {

        List<String> vaultIds = new ArrayList<>();
        vaultIds.add(vaultId);

        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.EMAIL, email);

    }

    @Given("^I have a customer with vaultId (.*) with email (.*) with no phoneNumber$")
    public void customerWithVaultidAndEmailAndNoPhone(String vaultId, String email) {

        List<String> vaultIds = new ArrayList<>();
        vaultIds.add(vaultId);

        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.EMAIL, email);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, null);

    }

    @Given("^I have a customer email (.*) with no phoneNumber and below vault ids$")
    public void customerWithVaultidAndEmailAndNoPhone(String email, List<String> vaultIds) {
        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.EMAIL, email);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, null);
    }

    @Given("^I have a customer with vaultId (.*) and phoneNumber (.*)$")
    public void customerWithVaultidAndPhoneNumber(String vaultId, String phoneNumber) {

        List<String> vaultIds = new ArrayList<>();
        vaultIds.add(vaultId);

        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, phoneNumber);

    }

    @Given("^I have a customer phoneNumber (.*) with vault ids$")
    public void customerWithVaultidAndPhoneNumber(String phoneNumber, List<String> vaultIds) {
        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, phoneNumber);
    }

    @Given("^I have a customer with email (.*)$")
    public void customerWithEmail(String email) {

        List<String> vaultIds = new ArrayList<>();

        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.EMAIL, email);

    }

    @Given("^I have a customer email (.*) with below vault ids$")
    public void customerWithEmailandMultipleVaultIds(String email, List<String> vaultIds) {

        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.EMAIL, email);

    }

    @Given("^I have a customer with phoneNumber (.*)$")
    public void customerWithPhoneNumber(String phoneNumber) {

        List<String> vaultIds = new ArrayList<>();

        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, phoneNumber);

    }

    @When("^I call customer value full detail api with filter (.*) and market (.*)$")
    public void customerFilters(String filter, String marketCode) {

        Set<String> filters = new HashSet<>();
        filters.add(filter);

        CustomerValueRequest customerValueRequest = CustomerValueRequest.builder()
                .vaultIds((List<String>) BaseStepDef.getAttribute(Utility.VAULT_ID))
                .email((String) BaseStepDef.getAttribute(Utility.EMAIL))
                .phoneNumber((String) BaseStepDef.getAttribute(Utility.PHONE_NUMBER))
                .filters(filters)
                .marketCode(marketCode)
                .build();

        BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_REQUEST, customerValueRequest);

    }

    @When("^I call customer value service for market (.*) with below filters$")
    public void customerFilters(String marketCode, List<String> filters) {

        Set<String> filtersSet = filters.stream().collect(Collectors.toSet());

        CustomerValueRequest customerValueRequest = CustomerValueRequest.builder()
                .vaultIds((List<String>) BaseStepDef.getAttribute(Utility.VAULT_ID))
                .email((String) BaseStepDef.getAttribute(Utility.EMAIL))
                .phoneNumber((String) BaseStepDef.getAttribute(Utility.PHONE_NUMBER))
                .filters(filtersSet)
                .marketCode(marketCode)
                .build();

        BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_REQUEST, customerValueRequest);

    }

    @Then("^I should expect (.*)$")
    public void iShouldSeeRewards(int statusCode) throws IOException {

        log.info("Calling post request for customer value service {}", Utility.CUSTOMER_VALUE_SERVICE_BASE_URL + CUSTOMER_VALUE_URL);
        objectMapper.findAndRegisterModules();

        CustomerValueRequest customerValueRequest = (CustomerValueRequest) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_REQUEST);
        log.info("customer value request -payload- {}",objectMapper.writeValueAsString(customerValueRequest) );
        Response response =  given()
                    .contentType(APPLICATION_JSON_UTF8_VALUE)
                    .content(objectMapper.writeValueAsString(customerValueRequest))
                    .headers("referer", Utility.REFERER_URL)
                    .expect().statusCode(statusCode)
                    .post(Utility.CUSTOMER_VALUE_SERVICE_BASE_URL + CUSTOMER_VALUE_URL);

        CustomerValueResponse customerValueResponse =
                objectMapper.readValue(response.body().asString(), CustomerValueResponse.class);

        BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_RESPONSE,customerValueResponse);

        log.info("CustValService Response -Here-  {}", response.body().asString());

    }

    @And("^I should find below mtl rewards in response$")
    public void assertDataTableForMtlRewards(DataTable dataTable) throws ParseException {

        List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);

        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);

        for(int i=0; i<list.size(); i++) {

            Map<String, String> dataRow = list.get(i);

            Optional<MtlDiscount> mtlDiscount =
                    customerValueResponse.getMtl().getRewards().stream()
                            .filter(w -> w.getPromotionCode().equalsIgnoreCase(dataRow.get(Utility.DT_PROMOTION_CODE))).findFirst();

            assertEquals(dataRow.get(Utility.DT_BAR_CODE), mtlDiscount.get().getBarCode());
            assertEquals(dataRow.get(Utility.DT_PROMOTION_ID), mtlDiscount.get().getPromotionId());
            assertEquals(new BigDecimal(dataRow.get(Utility.DT_RETAIL_VALUE)), mtlDiscount.get().getRetailValue());
            assertEquals(dataRow.get(Utility.DT_STATUS), mtlDiscount.get().getStatus());
            assertEquals(stringDateFormatter(dataRow.get(Utility.DT_END_DATE_TIME)), stringDateFormatter(mtlDiscount.get().getEndDateTime()));

        }

        log.debug("Assertion successful for Member Rewards!");

    }

    @And("^I should find below offer discounts in response$")
    public void assertDataTableForOffers(DataTable dataTable)  {

        List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);

        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);

        for(int i=0; i<list.size(); i++) {

            Map<String, String> dataRow = list.get(i);

            OfferDiscount offerDiscount =
                    customerValueResponse.getOffers().stream()
                            .filter(w -> w.getDiscount().getPromotionCode().equalsIgnoreCase(dataRow.get(Utility.DT_PROMOTION_CODE))).findFirst().get().getDiscount();

            assertEquals(dataRow.get(Utility.DT_BAR_CODE), offerDiscount.getBarCode());
            assertEquals(dataRow.get(Utility.DT_PROMOTION_ID), offerDiscount.getPromotionId());
            assertEquals(new BigDecimal(dataRow.get(Utility.DT_AMOUNT)), offerDiscount.getAmount());
        }

        log.debug("Assertion successful for Bounce Back Rewards!");

    }

    @And("^I should find below credit card rewards in response$")
    public void assertDataTableForCCRewards(DataTable dataTable) throws ParseException {

        List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);

        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);

        for(int i=0; i<list.size(); i++) {

            Map<String, String> dataRow = list.get(i);

            List<CreditCardReward> creditCardRewardList =
                    customerValueResponse.getCards().stream().
                            filter(w -> w.getIdentifier().equalsIgnoreCase(dataRow.get(Utility.DT_VAULT_ID))).findFirst().get().getRewards();

            CreditCardReward creditCardReward = creditCardRewardList.stream().
                    filter(w -> w.getPromotionCode().equalsIgnoreCase(dataRow.get(Utility.DT_PROMOTION_CODE))).findFirst().get();

            assertEquals(dataRow.get(Utility.DT_BAR_CODE), creditCardReward.getBarCode());
            assertEquals(dataRow.get(Utility.DT_PROMOTION_ID), creditCardReward.getPromotionId());
            assertEquals(dataRow.get(Utility.DT_RETAIL_VALUE), creditCardReward.getRetailValue().toString());
            assertEquals(stringDateFormatter(dataRow.get(Utility.DT_END_DATE_TIME)), stringDateFormatter(creditCardReward.getExpirationDateTime()));
        }

        log.debug("Assertion successful for Credit Card Rewards!");

    }

    @And("^I should be able to find below credit card rewards in response$")
    public void assertDataTableForCreditCardsRewards(DataTable dataTable) throws ParseException {

        List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);

        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);


        for(int i=0; i<list.size(); i++) {

            Map<String, String> dataRow = list.get(i);

            List<CreditCardReward> creditCardRewardList =
                    customerValueResponse.getCards().stream().
                            filter(w -> w.getIdentifier().equalsIgnoreCase(dataRow.get(Utility.DT_VAULT_ID))).findFirst().get().getRewards();

            assertNotNull(creditCardRewardList.get(i).getPromotionCode());
            assertNotNull(creditCardRewardList.get(i).getBarCode());
            assertNotNull(creditCardRewardList.get(i).getPromotionId());
            assertNotNull(creditCardRewardList.get(i).getRetailValue().toString());
            assertNotNull(stringDateFormatter(creditCardRewardList.get(i).getExpirationDateTime()));
        }

        log.debug("Assertion successful for Credit Card Rewards!");

    }

    @Then("^I should get a (\\d+) error code with an error message (.*)$")
    public void theMemberShouldGetABadRequestWithAnErrorMessage(int errorCode, String errorMessage) throws Throwable {

        log.debug("Calling post request for customer value service {} ", CUSTOMER_VALUE_URL);
        objectMapper.findAndRegisterModules();

        CustomerValueRequest customerValueRequest = (CustomerValueRequest) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_REQUEST);

        Response response =  given()
                .contentType(APPLICATION_JSON_UTF8_VALUE)
                .content(objectMapper.writeValueAsString(customerValueRequest))
                .headers("referer", Utility.REFERER_URL)
                .post(Utility.CUSTOMER_VALUE_SERVICE_BASE_URL + CUSTOMER_VALUE_URL);

        log.debug("Customer Value Response {}", response.body().asString());
        ErrorModel errorResponse =
                objectMapper.readValue(response.body().asString(), ErrorModel.class);
        assertNotNull(errorResponse);
        assertEquals(errorResponse.getStatusCode(), errorCode);
        assertEquals(errorResponse.getUserMessage(), errorMessage);
    }

    private Date stringDateFormatter(String strDate) throws ParseException {
        return new SimpleDateFormat(Utility.DATE_FORMATTER).parse(strDate);
    }


    @Given("^I have grant-type as (.*)$")
    public void customerWithGrantType(String grant_type) {
        BaseStepDef.setAttribute(Utility.GRANT_TYPE, grant_type);

    }

    @When("^I call Token Service$")
    public void tokenService() {
        log.debug("Calling token service");
        Response response = given()
                .formParam("grant_type",BaseStepDef.getAttribute(Utility.GRANT_TYPE))
                .headers("Authorization", Utility.AUTHORIZATION)
                .post(Utility.TOKEN_URL);
        BaseStepDef.setAttribute(Utility.TOKEN_RESPONSE, response);
        assertNotNull(response);

    }

    @Then("^I should get access token$")
    public void iShouldGetAccessToken() throws Throwable {
        log.debug("Getting access token from Token Response");
        Response response = (Response) BaseStepDef.getAttribute(Utility.TOKEN_RESPONSE);
        assertNotNull(response);
        String result = response.body().asString();
        log.debug("AccessToken Response {}", result);
        String[] splitWithComma = result.split(",");
        String[] splitWithColumn = splitWithComma[0].split(":");
        String access_token = splitWithColumn[1].replace("\"", "");
        log.debug("AccessToken Value after parsing the response: "+access_token);
        assertNotNull(response);
        assertEquals( 200,response.getStatusCode());
        BaseStepDef.setAttribute("access_token", access_token);
    }

    @Given("^customer with externalCustomerId (.*) has (.*)$")
    public void customerWithexternalCustomerId(String externalCustomerId,String type) {
        log.debug("The customer with ExternalCustomerId:"+externalCustomerId+" to get details of "+type);
        BaseStepDef.setAttribute("externalCustomerId", externalCustomerId);
    }

    @When("^I call customer value service full details api with externalCustomerId$")
    public void callCustomerValueServices() throws IOException {
        log.debug("Calling get request for customer value service {}", Utility.CUSTOMER_VALUE_APIGEE_BASE_URL);
        BaseStepDef.setAttribute("CUSTOMER_VALUE_GET_DETAILS_URL",Utility.CUSTOMER_VALUE_APIGEE_BASE_URL + BaseStepDef.getAttribute("externalCustomerId"));
        String GET_URL = (String) BaseStepDef.getAttribute("CUSTOMER_VALUE_GET_DETAILS_URL");
        String access_token = (String) BaseStepDef.getAttribute("access_token");
        Response response = given()
                .contentType(APPLICATION_JSON_UTF8_VALUE)
                .headers("Authorization", "Bearer"+access_token)
                .headers("client-id", "checkout")
                .get(GET_URL);
        assertNotNull(response);
        log.debug(response.body().asString());
        BaseStepDef.setAttribute(Utility.Customer_Value_Get_RESPONSE, response);
        if (response.getStatusCode() == 200) {
            CustomerValueResponse summaryResponse =
                    objectMapper.readValue(response.body().asString(), CustomerValueResponse.class);
            BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_RESPONSE, summaryResponse);
        }
    }

    @Then("^I should see (\\d+)$")
    public void seeResponseCode(int statusCode) throws Throwable {
        log.debug("Verifying the Customer value Response for response code");
        objectMapper.findAndRegisterModules();
        Response response = (Response) BaseStepDef.getAttribute(Utility.Customer_Value_Get_RESPONSE);
        assertEquals(statusCode,response.getStatusCode());
        log.debug("Customer Value Response status code {}", response.getStatusCode());
    }

    @Then("^I should be able to see a (\\d+) error code with an error message (.*)$")
    public void theMemberShouldGetErrorResponse(int errorCode, String errorMessage) throws Throwable {
        log.debug("Verifying the Customer value Response for error code");
        objectMapper.findAndRegisterModules();
        Response response = (Response) BaseStepDef.getAttribute(Utility.Customer_Value_Get_RESPONSE);
        ErrorModel errorResponse =
                objectMapper.readValue(response.body().asString(), ErrorModel.class);
        assertNotNull(errorResponse);
        assertEquals( errorCode,errorResponse.getStatus());
        assertEquals( errorMessage,errorResponse.getError());
        log.debug("Customer Value Response {}", response.body().asString());
    }


}
