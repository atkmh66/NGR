package com.gaptech.loyalty.customervalue.functionaltests.exception;

import lombok.EqualsAndHashCode;
import lombok.Value;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@Value
@EqualsAndHashCode(callSuper = false)
public class GapApiException extends Exception {

    private final ErrorModel error;

    public GapApiException(final Exception cause) {
        super(cause.getMessage(), cause);

        this.error = ErrorModel.builder()
            .statusCode(INTERNAL_SERVER_ERROR.value())
            .userMessage(cause.getMessage())
            .developerMessage(cause.getLocalizedMessage())
            .build();
    }
}
