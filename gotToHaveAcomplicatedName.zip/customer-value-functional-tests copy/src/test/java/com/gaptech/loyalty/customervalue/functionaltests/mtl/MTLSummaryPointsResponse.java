package com.gaptech.loyalty.customervalue.functionaltests.mtl;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class MTLSummaryPointsResponse {

    private int activePoints;
    private String memberId;
    private int pendingPoints;
    private int pointsUntilNextReward;
    private int rewardsToBeConvertedFromPoints;
    private int totalPoints;
}
