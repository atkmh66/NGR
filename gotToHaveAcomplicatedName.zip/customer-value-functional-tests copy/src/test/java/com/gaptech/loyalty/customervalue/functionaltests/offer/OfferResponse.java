package com.gaptech.loyalty.customervalue.functionaltests.offer;

import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class OfferResponse {

    public static final String GAP_ID = "1";
    public static final String GAP_FACTORY_ID = "5";

    private String brandCode;
    private DiscountResponse discount;
    private BurnPeriodResponse burnPeriod;
    private List<PromotionMessageResponse> promotionMessages;
    private List<String> applicableChannels;
    private String promotionId;

    public String getBrandCode() {
        if (brandCode.equals(GAP_FACTORY_ID)) {
            return GAP_ID;
        }
        return brandCode;
    }
}
