package com.gaptech.loyalty.customervalue.functionaltests.creditcard;

import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class CreditCardRewardRequest {

    private List<String> identifier;
    private String identifierFormat;
    private String market;
}
