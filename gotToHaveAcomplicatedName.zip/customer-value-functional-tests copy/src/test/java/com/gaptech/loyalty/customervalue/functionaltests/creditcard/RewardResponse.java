package com.gaptech.loyalty.customervalue.functionaltests.creditcard;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class RewardResponse {

    private Integer rewardId;
    private String promotionId;
    private DiscountResponse discount;
    private String message;
}
