package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

import java.math.BigDecimal;
import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Value
@Builder
public class CustomerValueSummaryResponse {

    @JsonProperty(value = "grandTotalAmount")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public BigDecimal grandTotalAmount;

    @JsonInclude(NON_NULL)
    @JsonProperty(value = "mtl")
    private Mtl mtl;

    @JsonInclude(NON_NULL)
    @JsonProperty(value = "offers")
    private List<OfferSummary> offers;

    @JsonInclude(NON_NULL)
    @JsonProperty(value = "cards")
    private List<CardSummary> cards;
}
