package com.gaptech.loyalty.customervalue.functionaltests.profile;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class BillingAddress {
    private String addressId;
    private String firstName;
    private String lastName;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String zipCode;
    private String countryCode;
    private String dayPhone;
    private String dpvCode;
    private Boolean isGuest;
    private String avsCode;
}
