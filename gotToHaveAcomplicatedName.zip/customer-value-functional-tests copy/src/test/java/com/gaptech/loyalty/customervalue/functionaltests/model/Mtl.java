package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

import java.math.BigDecimal;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Value
@Builder
@JsonInclude(NON_NULL)
public class Mtl {

    @JsonProperty(value = "mtlPoints")
    private MtlPoints mtlPoints;

    private BigDecimal totalRewards;

    private String memberId;

    private Tier tier;

    private String errorMessage;
}
