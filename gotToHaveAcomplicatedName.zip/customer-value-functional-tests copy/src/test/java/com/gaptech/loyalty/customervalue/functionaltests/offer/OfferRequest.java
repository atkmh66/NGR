package com.gaptech.loyalty.customervalue.functionaltests.offer;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class OfferRequest {

    private String email;
    private String market;
    private String offerType;
}
