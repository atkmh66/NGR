package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BurnPeriod {

    private String startDateTime;

    private String endDateTime;

    private int daysToRedeem;
    private boolean isExpired;
}
