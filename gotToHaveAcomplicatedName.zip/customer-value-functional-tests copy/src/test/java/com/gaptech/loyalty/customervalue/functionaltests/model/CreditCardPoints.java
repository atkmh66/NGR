package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditCardPoints {
    private int adjustments;
    private int basePointsEarnedInGapBrands;
    private int basePointsEarnedOutsideGapBrands;
    private int bonusPointsEarnedInGapBrands;
    private int bonusPointsEarnedOutsideGapBrands;
    private int currentPointsBalance;
    private int customerCapture;
    private boolean maxRewardAchieved;
    private int pointsFromReturnedItems;
    private int pointsRemainingUntilTierStatus;
    private int pointsRolledOverSinceLastStatement;
    private int pointsToBeConvertedToRewards;
    private int pointsUntilNextReward;
    private int quarterlyBonusPoints;
    private int remainingPointsBalance;
    private int rewardsToBeConvertedFromPoints;
    private int totalPointsEarnedTowardsTierStatus;
    private int totalProgressTowardsTierStatus;
    private int pointsYearToDate;
}
