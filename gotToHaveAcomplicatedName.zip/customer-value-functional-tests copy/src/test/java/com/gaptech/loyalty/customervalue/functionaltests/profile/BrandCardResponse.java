package com.gaptech.loyalty.customervalue.functionaltests.profile;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class BrandCardResponse {

    @JsonProperty(value = "vaultId")
    private String vaultId;
    
    @JsonProperty(value = "dateOfBirth")
    private String dateOfBirth;
    
    @JsonProperty(value = "type")
    private String type;
    
    @JsonProperty(value = "plccBrand")
    private String plccBrand;
    
    @JsonProperty(value = "creditCardTier")
    private String creditCardTier;
    
    @JsonProperty(value = "issueDate")
    private String issueDate;
    
    @JsonProperty(value = "nearTierCode")
    private String nearTierCode;
    
    @JsonProperty(value = "createdBy")
    private String createdBy;
    
    @JsonProperty(value = "updatedBy")
    private String updatedBy;
    
    @JsonProperty(value = "creationDate")
    private String creationDate;
    
    @JsonProperty(value = "updateDate")
    private String updateDate;
    
    @JsonProperty(value = "links")
    private List<Links> links;
}
