package com.gaptech.loyalty.customervalue.functionaltests.offer;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class BurnPeriodResponse {

    private String startDateTime;
    private String endDateTime;
    private int daysToRedeem;
}
