package com.gaptech.loyalty.customervalue.functionaltests.promotion;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Setter
@Getter
public class Award {

    private BigDecimal awardAmount;
    private String awardType;
}
