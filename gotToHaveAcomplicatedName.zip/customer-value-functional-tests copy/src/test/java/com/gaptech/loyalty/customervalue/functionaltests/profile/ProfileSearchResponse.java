package com.gaptech.loyalty.customervalue.functionaltests.profile;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProfileSearchResponse {
    String vaultId;
    String dateOfBirth;
    String firstName;
    String lastName;
    String accountStatus;
    String type;
    String plccBrand;
    String creditCardTier;
    String issueDate;
    String createdBy;
    String updatedBy;
    String creationDate;
    String updateDate;
}
