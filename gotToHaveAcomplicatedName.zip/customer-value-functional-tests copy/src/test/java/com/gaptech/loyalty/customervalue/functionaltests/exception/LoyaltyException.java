package com.gaptech.loyalty.customervalue.functionaltests.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;

import java.io.IOException;

@Getter
public class LoyaltyException extends RuntimeException {

    private final int status;
    private final ErrorModel errorModel;

    public LoyaltyException(int status, ErrorModel errorModel, Throwable cause) {
        super(cause);
        this.errorModel = errorModel;
        this.status = status;
    }

    public LoyaltyException(int status, String errorModel, Throwable cause) throws IOException {
        this(status, new ObjectMapper().readValue(errorModel, ErrorModel.class), cause);
    }

    public LoyaltyException(int status, Throwable cause) {
        this(status, ErrorModel.builder().statusCode(status).userMessage("").build(), cause);
    }
}
