package com.gaptech.loyalty.customervalue.functionaltests.mtl;

import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class MTLSummaryRequest {

    private List<MTLSummarySearchCriteriaRequest> searchCriteria;
}
