package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Value;

import java.util.List;

@Value
@Builder
@EqualsAndHashCode()
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditCard {

    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String phoneNumber;
    private String enrollmentDate;
    private String identifier;
    private String brandCode;
    private String cardHolderName;
    private String lastFourDigits;
    private String tier;
    private String type;
    private CreditCardPoints points;
    private List<CreditCardReward> rewards;

    private String errorMessage;
}
