package com.gaptech.loyalty.customervalue.functionaltests.promotion;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PromotionLocaleValue {

    private String localeCode;
    private String legalTermText;
}
