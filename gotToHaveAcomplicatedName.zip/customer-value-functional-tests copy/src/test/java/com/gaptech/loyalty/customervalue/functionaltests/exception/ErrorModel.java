package com.gaptech.loyalty.customervalue.functionaltests.exception;

import lombok.Builder;
import lombok.Value;

@Value

@Builder
public class ErrorModel {

    private int statusCode;

    private String errorCode;

    private String developerMessage;

    private String userMessage;
    private String message;

    private String path;

    private String timestamp;

    private String moreInfo = "https://stage.api.azeus.gaptech.com/commerce/customer-value/swagger-ui.html";

    private int status;

    private String error;



}
