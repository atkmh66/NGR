package com.gaptech.loyalty.customervalue.functionaltests.common.stepdef;

import com.gaptech.loyalty.customervalue.functionaltests.common.ContextAttributes;
import com.jayway.restassured.response.Response;

public class BaseStepDef {

    public static Object getAttribute(String attributeName) {
        return context().getAttribute(attributeName);
    }

    private static ContextAttributes context() {
        return ContextAttributes.getInstance();
    }

    public static void setAttribute(String attributeName, Object value) {
        context().setAttribute(attributeName, value);
    }

    public static void clear() {
        context().clear();
    }

    public static Response getResponse() {
        return (Response) context().getAttribute("response");
    }

}
