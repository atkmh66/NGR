package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class RewardsResponse {

    private String type;

    @JsonProperty(value = "creditCard")
    private CreditCard creditCardResponse;

    @JsonProperty(value = "discount")
    private List<MtlDiscount> discountResponses;
}
