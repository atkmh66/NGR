package com.gaptech.loyalty.customervalue.functionaltests.promotion;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;

import java.util.ArrayList;
import java.util.List;

@Builder
public class PromotionCollectionResponse {

    @JsonProperty("promotions")
    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    private List<PromotionDetailsResponse> promotionDetails;

    public List<PromotionDetailsResponse> getPromotionDetails() {
        if (this.promotionDetails == null) {
            this.promotionDetails = new ArrayList<>();
        }
        return promotionDetails;
    }
}
