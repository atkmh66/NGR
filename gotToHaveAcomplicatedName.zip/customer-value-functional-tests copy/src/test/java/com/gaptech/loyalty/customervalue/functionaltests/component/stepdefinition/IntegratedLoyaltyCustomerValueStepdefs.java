package com.gaptech.loyalty.customervalue.functionaltests.component.stepdefinition;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gaptech.loyalty.customervalue.functionaltests.common.Utility;
import com.gaptech.loyalty.customervalue.functionaltests.common.stepdef.BaseStepDef;
import com.gaptech.loyalty.customervalue.functionaltests.exception.ErrorModel;
import com.gaptech.loyalty.customervalue.functionaltests.model.CreditCard;
import com.gaptech.loyalty.customervalue.functionaltests.model.CreditCardReward;
import com.gaptech.loyalty.customervalue.functionaltests.model.CustomerValueRequest;
import com.gaptech.loyalty.customervalue.functionaltests.model.CustomerValueResponse;
import com.gaptech.loyalty.customervalue.functionaltests.model.MtlDiscount;
import com.gaptech.loyalty.customervalue.functionaltests.model.Offer;
import com.jayway.restassured.filter.log.RequestLoggingFilter;
import com.jayway.restassured.filter.log.ResponseLoggingFilter;
import com.jayway.restassured.response.Response;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static com.jayway.restassured.RestAssured.given;
import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@Slf4j
public class IntegratedLoyaltyCustomerValueStepdefs {
    private ObjectMapper objectMapper = new ObjectMapper();

    @Given("^I have exiting grant-type as (.*)$")
    public void exitingGrantType(String grant_type) {
        BaseStepDef.setAttribute(Utility.GRANT_TYPE, grant_type);
    }

    @When("^I call daemon token service$")
    public void callDaemonTokenService() {
        log.debug("Calling daemon token service....");
        Response response = given()
                .formParam("grant_type", BaseStepDef.getAttribute(Utility.GRANT_TYPE))
                .headers("Authorization", Utility.AUTHORIZATION)
                .post(Utility.TOKEN_URL);
        BaseStepDef.setAttribute(Utility.TOKEN_RESPONSE, response);
        assertNotNull(response);
    }

    @Then("^I should return access token$")
    public void iShouldReturnAccessToken() {
        log.debug("Getting access token from daemon token response...");
        Response response = (Response) BaseStepDef.getAttribute(Utility.TOKEN_RESPONSE);
        assertNotNull(response);
        String result = response.body().asString();
        log.debug("Daemon Access Token Response [{}]", result);
        String[] splitWithComma = result.split(",");
        String[] splitWithColumn = splitWithComma[0].split(":");
        String access_token = splitWithColumn[1].replace("\"", "");
        log.debug("Daemon Access Token after parsing the response [{}] ", access_token);
        assertEquals(200, response.getStatusCode());
        BaseStepDef.setAttribute(Utility.ACCESS_TOKEN, access_token);
    }

    @Given("^Integrated loyalty request with headers client-id (.*) and apiVersion (.*)$")
    public void integratedLoyaltyFlagAndHeaderApiVersion(String clientId, String apiVersion) {
        BaseStepDef.setAttribute(Utility.CLIENT_ID_HEADER, clientId);
        BaseStepDef.setAttribute(Utility.API_VERSION_HEADER, apiVersion);
    }

    @Given("^A loyalty customer with email (.*)$")
    public void integratedLoyaltyCustomerWithEmail(String email) {
        BaseStepDef.setAttribute(Utility.EMAIL, email);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, null);
        BaseStepDef.setAttribute(Utility.VAULT_ID, null);
        BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, null);
    }

    @Given("^A loyalty customer whose email (.*) and phoneNumber (.*)$")
    public void integratedLoyaltyCustomerWithEmail(String email, String phoneNumber) {
        BaseStepDef.setAttribute(Utility.EMAIL, email);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, phoneNumber);
        BaseStepDef.setAttribute(Utility.VAULT_ID, null);
        BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, null);
    }

    @When("^Make post call to integrated loyalty customer value full detail api with market (.*), brand (.*)" +
            " and below filters$")
    public void postCallToIntegratedLoyaltyCustomerValueFullDetailApi(String market, String brand,
                                                                      List<String> filters) throws IOException {
        log.info("Calling customer value service [{}]", Utility.CVS_APIGEE_BASE_URL);
        log.info("Just finished a log.info() command_X");
        if (filters.contains("NULL")) {
            filters = new ArrayList<>();
        }

        Set<String> filterSet = filters.stream().collect(Collectors.toSet());
        CustomerValueRequest customerValueRequest = CustomerValueRequest.builder()
                .vaultIds((List<String>) BaseStepDef.getAttribute(Utility.VAULT_ID))
                .email((String) BaseStepDef.getAttribute(Utility.EMAIL))
                .phoneNumber((String) BaseStepDef.getAttribute(Utility.PHONE_NUMBER))
                .brand(brand)
                .filters(filterSet)
                .marketCode(market)
                .externalCustomerId((String) BaseStepDef.getAttribute(Utility.EXTERNAL_CUSTOMER_ID))
                .build();

        BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_REQUEST, customerValueRequest);
// Mark Adds start
        log.info("customer value request -payload- {}",objectMapper.writeValueAsString(customerValueRequest));
// Mark adds finish
        Map<String, String> headers = new HashMap<>();
        headers.put(Utility.CLIENT_ID_HEADER, (String) BaseStepDef.getAttribute(Utility.CLIENT_ID_HEADER));
        String accessToken = (String) BaseStepDef.getAttribute(Utility.ACCESS_TOKEN);
        headers.put(Utility.AUTH_HEADER, Utility.TOKEN_TYPE_BEARER + accessToken);
        headers.put(Utility.API_VERSION_HEADER, (String) BaseStepDef.getAttribute(Utility.API_VERSION_HEADER));

        Response response = given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter())
                .contentType(APPLICATION_JSON_UTF8_VALUE)
                .content(objectMapper.writeValueAsString(customerValueRequest))
                .headers(headers)
                .when()
                .post(Utility.CVS_APIGEE_BASE_URL);
// Mark Adds start
        log.info("CustValService Response -Here-  {}", response.body().asString());
// Mark adds finish
        assertNotNull(response);

        BaseStepDef.setAttribute(Utility.RESPONSE, response);
        if (response.getStatusCode() == 200 && Objects.nonNull(response.body())) {
            CustomerValueResponse customerValueResponse =
                    objectMapper.readValue(response.body().asString(), CustomerValueResponse.class);
            BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_RESPONSE, customerValueResponse);
            log.info("Customer Value Response [{}]", response.body().asString());
        } else {
            log.info("Customer Value Response [{}]", response.getStatusLine());
        }
    }

    @Then("^Call should return (.*) status code$")
    public void callShouldReturnStatusCode(int statusCode) {
        log.debug("Verifying the Customer value Response for response code");
        Response response = (Response) BaseStepDef.getAttribute(Utility.RESPONSE);
        log.debug("Customer Value Response status code {}", response.getStatusCode());
        assertEquals(statusCode, response.getStatusCode());
    }

    @And("^Should return mtl rewards response and validate response data fields such as promotionId, promotionCode," +
            " barCode, retailValue, status and endDateTime$")
    public void shouldReturnMtlRewardsResponseAndValidateResponseData() {
        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);

        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getMtl());
        assertNotNull(customerValueResponse.getMtl().getRewards());
        assertFalse(customerValueResponse.getMtl().getRewards().isEmpty());

        customerValueResponse.getMtl().getRewards()
                .stream()
                .forEach(this::validateMTLReward);

        log.debug("Assertion successful for MTL Rewards!!!");

    }

    private void validateMTLReward(MtlDiscount reward) {
        assertNotNull(reward);
        assertNotNull(reward.getPromotionId());
        assertNotNull(reward.getPromotionCode());
        assertNotNull(reward.getBarCode());
        assertTrue(reward.getRetailValue().compareTo(BigDecimal.ZERO) > 0);
        assertEquals(reward.getStatus(), "A");
        assertFalse(Utility.isExpire(reward.getEndDateTime()));
    }

    @And("^Should return mtl points response and validate response data fields such as activePoints, pendingPoints," +
            " totalPoints, activePointsAmount, pendingPointsAmount and totalPointsAmount$")
    public void shouldReturnMtlPointsResponseAndValidateResponseData() {
        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);
        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getMtl());
        assertNotNull(customerValueResponse.getMtl().getPoints());
        assertTrue(customerValueResponse.getMtl().getPoints().getActivePoints() >= 0);
        assertTrue(customerValueResponse.getMtl().getPoints().getPendingPoints() >= 0);
        assertTrue(customerValueResponse.getMtl().getPoints().getTotalPoints() >= 0);
        int expectedTotalPoints = customerValueResponse.getMtl().getPoints().getTotalPoints();
        int calculatedTotalPoints = customerValueResponse.getMtl().getPoints().getActivePoints()
                + customerValueResponse.getMtl().getPoints().getPendingPoints();
        assertEquals(expectedTotalPoints, calculatedTotalPoints);
        assertTrue(customerValueResponse.getMtl().getPoints().getActivePointsAmount()
                .compareTo(BigDecimal.ZERO) >= 0);
        assertTrue(customerValueResponse.getMtl().getPoints().getPendingPointsAmount()
                .compareTo(BigDecimal.ZERO) >= 0);
        assertTrue(customerValueResponse.getMtl().getPoints().getTotalPointsAmount()
                .compareTo(BigDecimal.ZERO) >= 0);
        BigDecimal expectedTotalPointsAmount = customerValueResponse.getMtl().getPoints().getTotalPointsAmount();
        BigDecimal calculatedTotalPointsAmount = customerValueResponse.getMtl().getPoints().getActivePointsAmount()
                .add(customerValueResponse.getMtl().getPoints().getPendingPointsAmount());
        assertEquals(expectedTotalPointsAmount, calculatedTotalPointsAmount);
        log.debug("Assertion successful for MTL Points for various fields data!!!");
    }

    @Given("^A loyalty customer with phoneNumber (.*)$")
    public void integratedLoyaltyCustomerWithPhoneNumber(String phoneNumber) {
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, phoneNumber);
        BaseStepDef.setAttribute(Utility.EMAIL, null);
        BaseStepDef.setAttribute(Utility.VAULT_ID, null);
        BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, null);
    }

    @And("^Should return credit card rewards response and validate response data fields such as promotionId," +
            " promotionCode, barCode, retailValue, status, endDateTime and vaultId$")
    public void shouldReturnCreditCardRewardsResponseAndValidateResponseData() {
        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);
        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getCards());
        assertFalse(customerValueResponse.getCards().isEmpty());
        customerValueResponse.getCards()
                .stream()
                .forEach(this::validateCreditCardsForRewards);

        log.debug("Assertion successful for Credit Card Rewards!!!");
    }

    private void validateCreditCardsForRewards(CreditCard creditCard) {
        assertNotNull(creditCard);
        assertNotNull(creditCard.getRewards());
        assertFalse(creditCard.getRewards().isEmpty());
        creditCard.getRewards()
                .stream()
                .forEach(this::validateCreditCardRewards);
    }

    private void validateCreditCardRewards(CreditCardReward creditCardReward) {
        assertNotNull(creditCardReward);
        assertNotNull(creditCardReward.getPromotionId());
        assertNotNull(creditCardReward.getPromotionCode());
        assertNotNull(creditCardReward.getBarCode());
        assertTrue(creditCardReward.getRetailValue() > 0);
        assertFalse(Utility.isExpire(creditCardReward.getExpirationDateTime()));
    }

    @Given("^A loyalty customer with externalCustomerId (.*)$")
    public void integratedLoyaltyCustomerWithExternalCustomerId(String externalCustomerId) {
        BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, externalCustomerId);
        BaseStepDef.setAttribute(Utility.EMAIL, null);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, null);
        BaseStepDef.setAttribute(Utility.VAULT_ID, null);
    }

    @And("^Should not return any mtlRewards$")
    public void shouldNotReturnMtlRewards() {
        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);
        assertNull(customerValueResponse.getMtl());
        log.debug("Assertion successful for no MTL Rewards!!!");
    }

    @And("^Should not return any mtlPoints$")
    public void shouldReturnMtlPoints() {
        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);
        assertNotNull(customerValueResponse.getMtl());
        assertNull(customerValueResponse.getMtl().getPoints());
        log.debug("Assertion successful no MTL Points for v2!!!");
    }

    @And("^Should return offers response and validate response data fields such as promotionId, promotionCode, barCode," +
            " amount and isExpired$")
    public void shouldReturnOffersResponseAndValidateResponseData() {
        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);
        assertNotNull(customerValueResponse.getOffers());
        assertFalse(customerValueResponse.getOffers().isEmpty());
        customerValueResponse.getOffers()
                .stream()
                .forEach(this::validateOffers);
    }

    private void validateOffers(Offer offer) {
        assertNotNull(offer);
        assertNotNull(offer.getDiscount());
        assertNotNull(offer.getDiscount().getPromotionId());
        assertNotNull(offer.getDiscount().getBarCode());
        assertNotNull(offer.getDiscount().getPromotionCode());
        assertTrue(offer.getDiscount().getAmount().compareTo(BigDecimal.ZERO) > 0);
        assertNotNull(offer.getBurnPeriod());
        assertNotNull(offer.getBurnPeriod().getEndDateTime());
        if (Utility.isExpire(offer.getBurnPeriod().getEndDateTime())) {
            assertTrue(offer.getBurnPeriod().isExpired());
        }
        assertTrue(offer.getBurnPeriod().getDaysToRedeem() >= 0);
    }

    @Then("^Call should return (.*) status code and error message should contain (.*)$")
    public void callShouldReturnStatusCodeAndErrorMessage(int statusCode, String errorMessage) throws IOException {
        log.debug("Customer Value Response status code and error message...");
        Response response = (Response) BaseStepDef.getAttribute(Utility.RESPONSE);
        ErrorModel errorResponse =
                objectMapper.readValue(response.body().asString(), ErrorModel.class);
        assertNotNull(errorResponse);
        assertEquals(errorResponse.getStatusCode(), statusCode);
        assertTrue(errorResponse.getDeveloperMessage().contains(errorMessage));
    }

    @Given("^A loyalty customer whose phoneNumber (.*) and VaultIds (.*)$")
    public void IntegratedLoyaltyCustomerWithPhoneNumberAndVaultIds(String phoneNumber, List<String> vaultIds) {
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, phoneNumber);
        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.EMAIL, null);
        BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, null);
    }

    @Given("^A loyalty customer with VaultIds (.*) and email (.*)$")
    public void integratedLoyaltyCustomerWithVaultIdsAndEmail(List<String> vaultIds, String email) {
        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.EMAIL, email);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, null);
        BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, null);
    }

    @Given("^A loyalty customer whose externalCustomerId (.*) and email (.*)$")
    public void integratedLoyaltyCustomerWhoseExternalCustomerIdAndEmail(String externalCustomerId, String email) {
        BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, externalCustomerId);
        BaseStepDef.setAttribute(Utility.EMAIL, email);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, null);
        BaseStepDef.setAttribute(Utility.VAULT_ID, null);
    }

    @Given("^A loyalty customer with below VaultIds$")
    public void integratedLoyaltyCustomerWithVaultIds(List<String> vaultIds) {
        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.EMAIL, null);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, null);
        BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, null);
    }

    @When("^Make post call to loyalty customer value full detail api with market (.*) and below filters$")
    public void makePostCallToLoyaltyCustomerValueFullDetailApiWithFilters(String market, List<String> filters)
            throws IOException {
        log.debug("Calling customer value service [{}]", Utility.CVS_APIGEE_BASE_URL);

        if (filters.contains("NULL")) {
            filters = new ArrayList<>();
        }

        Set<String> filterSet = filters.stream().collect(Collectors.toSet());
        CustomerValueRequest customerValueRequest = CustomerValueRequest.builder()
                .vaultIds((List<String>) BaseStepDef.getAttribute(Utility.VAULT_ID))
                .email((String) BaseStepDef.getAttribute(Utility.EMAIL))
                .phoneNumber((String) BaseStepDef.getAttribute(Utility.PHONE_NUMBER))
                .filters(filterSet)
                .externalCustomerId((String) BaseStepDef.getAttribute(Utility.EXTERNAL_CUSTOMER_ID))
                .marketCode(market)
                .build();

        BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_REQUEST, customerValueRequest);


        Map<String, String> headers = new HashMap<>();
        String accessToken = (String) BaseStepDef.getAttribute(Utility.ACCESS_TOKEN);
        headers.put(Utility.AUTH_HEADER, Utility.TOKEN_TYPE_BEARER + accessToken);

        Response response = given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter())
                .contentType(APPLICATION_JSON_UTF8_VALUE)
                .content(objectMapper.writeValueAsString(customerValueRequest))
                .headers(headers)
                .when()
                .post(Utility.CVS_APIGEE_BASE_URL);

        assertNotNull(response);

        BaseStepDef.setAttribute(Utility.RESPONSE, response);
        log.debug("Customer Value Response [{}]", response.getStatusLine());
        if (response.getStatusCode() == 200 && Objects.nonNull(response.body())) {
            CustomerValueResponse customerValueResponse =
                    objectMapper.readValue(response.body().asString(), CustomerValueResponse.class);
            BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_RESPONSE, customerValueResponse);
            log.debug("Customer Value Response body [{}]", response.body().asString());
        }
    }

    @And("^Should return mtl points response and validate response data fields such as activePoints, pendingPoints," +
            " totalPoints, rewardsToBeConvertedFromPoints and pointsUntilNextReward$")
    public void shouldReturnV1MtlPointsResponseAndValidateResponseData() {
        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);
        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getMtl());
        assertNotNull(customerValueResponse.getMtl().getPoints());
        assertTrue(customerValueResponse.getMtl().getPoints().getActivePoints() >= 0);
        assertTrue(customerValueResponse.getMtl().getPoints().getPendingPoints() >= 0);
        assertTrue(customerValueResponse.getMtl().getPoints().getTotalPoints() >= 0);
        assertTrue(customerValueResponse.getMtl().getPoints().getRewardsToBeConvertedFromPoints() >= 0);
        assertTrue(customerValueResponse.getMtl().getPoints().getPointsUntilNextReward() >= 0);
        int expectedTotalPoints = customerValueResponse.getMtl().getPoints().getTotalPoints();
        int calculatedTotalPoints = customerValueResponse.getMtl().getPoints().getActivePoints()
                + customerValueResponse.getMtl().getPoints().getPendingPoints();
        assertEquals(expectedTotalPoints, calculatedTotalPoints);
        log.debug("Assertion successful for V1 MTL Points for various fields data!");
    }

    @When("^Make get call to integrated loyalty customer value get full detail api with market (.*), brand (.*)" +
            " and channel (.*)$")
    public void makeGetCallToIntegratedLoyaltyCustomerValueGetFullDetailApiWithMarketAndBrand(String market,
                                                                                              String brand,
                                                                                              String channel)
            throws IOException {
        BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_GET_DETAILS_URL, Utility
                .CUSTOMER_VALUE_APIGEE_BASE_URL + BaseStepDef.getAttribute(Utility.EXTERNAL_CUSTOMER_ID));
        String GET_URL = (String) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_GET_DETAILS_URL);
        log.debug("Calling get request for customer value service [{}]", GET_URL);
        String accessToken = (String) BaseStepDef.getAttribute(Utility.ACCESS_TOKEN);
        Map<String, String> queryParamsList = new HashMap<>();
        queryParamsList.put("marketCode", market);
        queryParamsList.put("brand", brand);
        queryParamsList.put("channel", channel);
        Response response = given()
                .contentType(APPLICATION_JSON_UTF8_VALUE)
                .header(Utility.AUTH_HEADER, Utility.TOKEN_TYPE_BEARER + accessToken)
                .and()
                .header(Utility.CLIENT_ID_HEADER, BaseStepDef.getAttribute(Utility.CLIENT_ID_HEADER))
                .and()
                .header(Utility.API_VERSION_HEADER, BaseStepDef.getAttribute(Utility.API_VERSION_HEADER))
                .and()
                .queryParams(queryParamsList)
                .when()
                .get(GET_URL);
        assertNotNull(response);
        BaseStepDef.setAttribute(Utility.RESPONSE, response);
        log.debug("Customer Value Response via GET [{}]", response.getStatusLine());
        if (response.getStatusCode() == 200) {
            CustomerValueResponse summaryResponse =
                    objectMapper.readValue(response.body().asString(), CustomerValueResponse.class);
            BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_RESPONSE, summaryResponse);
            log.debug("Customer Value Response via GET [{}]", response.body().asString());
        }
    }

    @And("^Should return credit card points response and validate response data fields such as" +
            " pointsRolledOverSinceLastStatement, basePointsEarnedInGapBrands, bonusPointsEarnedInGapBrands," +
            " basePointsEarnedOutsideGapBrands, bonusPointsEarnedOutsideGapBrands, quarterlyBonusPoints," +
            " pointsFromReturnedItems, pointsToBeConvertedToRewards, rewardsToBeConvertedFromPoints," +
            " remainingPointsBalance and currentPointsBalance$")
    public void shouldReturnCreditCardPointsResponseAndValidateResponseData() {
        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);
        assertNotNull(customerValueResponse);
        assertNotNull(customerValueResponse.getCards());
        assertFalse(customerValueResponse.getCards().isEmpty());

        customerValueResponse.getCards().stream().forEach(creditCard -> validateCreditCardForPoints(creditCard));
        log.debug("Assertion successful for Credit Card Points for various fields data!!!");
    }

    private void validateCreditCardForPoints(CreditCard creditCard) {
        assertNotNull(creditCard);
        assertNotNull(creditCard.getPoints());
        assertTrue(creditCard.getPoints().getPointsRolledOverSinceLastStatement() >= 0);
        assertTrue(creditCard.getPoints().getBasePointsEarnedInGapBrands() >= 0);
        assertTrue(creditCard.getPoints().getBonusPointsEarnedInGapBrands() >= 0);
        assertTrue(creditCard.getPoints().getBasePointsEarnedOutsideGapBrands() >= 0);
        assertTrue(creditCard.getPoints().getBonusPointsEarnedOutsideGapBrands() >= 0);
        assertTrue(creditCard.getPoints().getQuarterlyBonusPoints() >= 0);
        assertTrue(creditCard.getPoints().getPointsFromReturnedItems() >= 0);
        assertTrue(creditCard.getPoints().getPointsToBeConvertedToRewards() >= 0);
        assertTrue(creditCard.getPoints().getRewardsToBeConvertedFromPoints() >= 0);
        assertTrue(creditCard.getPoints().getRemainingPointsBalance() >= 0);
        assertTrue(creditCard.getPoints().getCurrentPointsBalance() >= 0);
    }

    @Given("^A loyalty customer whose email (.*) and VaultIds$")
    public void customerWhoseEmailAndVaultIds(String email, List<String> vaultIds) {
        BaseStepDef.setAttribute(Utility.EMAIL, email);
        BaseStepDef.setAttribute(Utility.VAULT_ID, vaultIds);
        BaseStepDef.setAttribute(Utility.PHONE_NUMBER, null);
        BaseStepDef.setAttribute(Utility.EXTERNAL_CUSTOMER_ID, null);
    }

    @And("^Should return empty mtlRewards$")
    public void shouldReturnEmptyMtlRewards() {
        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);
        assertNotNull(customerValueResponse.getMtl());
        assertNotNull(customerValueResponse.getMtl().getRewards());
        assertTrue(customerValueResponse.getMtl().getRewards().isEmpty());
        log.debug("Assertion successful for empty MTL Rewards!!!");
    }

    @And("^Should not return mtlPoints$")
    public void shouldNotReturnMtlPoints() {
        CustomerValueResponse customerValueResponse = (CustomerValueResponse) BaseStepDef
                .getAttribute(Utility.CUSTOMER_VALUE_RESPONSE);
        assertNull(customerValueResponse.getMtl());
        log.debug("Assertion successful for no MTL Points in v1!!!");
    }

    @When("^Make get call to integrated loyalty customer value get full detail api$")
    public void makeGetCallToIntegratedLoyaltyCustomerValueGetFullDetailApi() throws IOException {
        BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_GET_DETAILS_URL, Utility
                .CUSTOMER_VALUE_APIGEE_BASE_URL + BaseStepDef.getAttribute(Utility.EXTERNAL_CUSTOMER_ID));
        String GET_URL = (String) BaseStepDef.getAttribute(Utility.CUSTOMER_VALUE_GET_DETAILS_URL);
        log.debug("Calling get request for customer value service [{}]", GET_URL);
        String accessToken = (String) BaseStepDef.getAttribute(Utility.ACCESS_TOKEN);
        Response response = given()
                .contentType(APPLICATION_JSON_UTF8_VALUE)
                .headers(Utility.AUTH_HEADER, Utility.TOKEN_TYPE_BEARER + accessToken)
                .get(GET_URL);
        assertNotNull(response);
        BaseStepDef.setAttribute(Utility.RESPONSE, response);
        log.debug("Customer Value Response via GET [{}]", response.getStatusLine());
        if (response.getStatusCode() == 200) {
            CustomerValueResponse summaryResponse =
                    objectMapper.readValue(response.body().asString(), CustomerValueResponse.class);
            BaseStepDef.setAttribute(Utility.CUSTOMER_VALUE_RESPONSE, summaryResponse);
            log.debug("Customer Value Response via GET [{}]", response.body().asString());
        }
    }
}

