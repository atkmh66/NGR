package com.gaptech.loyalty.customervalue.functionaltests.model;

public enum Tier {
    CORE, ENTHUSIAST, ICON
}
