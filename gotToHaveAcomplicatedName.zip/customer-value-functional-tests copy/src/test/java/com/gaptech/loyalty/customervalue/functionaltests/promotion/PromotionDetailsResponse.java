package com.gaptech.loyalty.customervalue.functionaltests.promotion;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.ZonedDateTime;
import java.util.List;

@Setter
@Getter
@Builder
public class PromotionDetailsResponse {

    @JsonProperty("id")
    private String promotionId;

    /*
     * private String status;
     */

    private String code;

    private String name;

    private String legalTerms;

    private String subcategoryCode;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "E MMM dd HH:mm:ss z yyyy")
    private ZonedDateTime startDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "E MMM dd HH:mm:ss z yyyy")
    private ZonedDateTime endDate;

    private String marketingDescription;

    private String createdBy;

    private String updatedBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "E MMM dd HH:mm:ss z yyyy")
    private ZonedDateTime creationDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "E MMM dd HH:mm:ss z yyyy")
    private ZonedDateTime updatedDate;

    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    private List<PromotionBranchChannels> promotionBrandChannels;

    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    private List<PromotionTier> promotionTiers;

    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    private List<PromotionLocaleValue> promotionLocaleValues;
}
