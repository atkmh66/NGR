package com.gaptech.loyalty.customervalue.functionaltests.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.gaptech.loyalty.customervalue.functionaltests.profile.CustomerInformation;
import lombok.Builder;
import lombok.Value;

import java.math.BigDecimal;
import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Value
@Builder
public class CustomerValueResponse {

    private CustomerInformation customer;

    private MemberSummary mtl;

    @JsonInclude(NON_NULL)
    private List<Offer> offers;

    @JsonInclude(NON_NULL)
    private List<CreditCard> cards;

    @JsonInclude(NON_NULL)
    private String errorMessage;

    @JsonProperty(value = "grandTotalAmount")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public BigDecimal grandTotalAmount;

    @JsonInclude(NON_NULL)
    private String externalCustomerId;
}
