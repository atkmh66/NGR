package com.gaptech.loyalty.customervalue.functionaltests;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration(classes = {CustomerValueFunctionalTestApplication.class})
public class CustomerValueFunctionalTestApplicationTests {

        @Test
        public void contextLoads() {
        }
}

