package com.gaptech.loyalty.customervalue.functionaltests.offer;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

import java.math.BigDecimal;

@Value
@Builder
public class DiscountResponse {

    private String code;
    private String barCode;
    private BigDecimal amount;
    private String type;
    @JsonProperty("startDateTime")
    private String startDate;
    @JsonProperty("endDateTime")
    private String endDate;
    private String legalTerms;
    
}
